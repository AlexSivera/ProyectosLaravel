@extends('plantilla')

@section('titulo', 'Ficha del post')

@section('contenido')
    <h1>Ficha del post {{ $id }}</h1>
@endsection
