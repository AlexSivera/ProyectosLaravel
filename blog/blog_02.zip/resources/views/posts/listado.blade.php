@extends('plantilla')

@section('titulo', 'Listado de posts')

@section('contenido')
    <h1>Listado de posts</h1>
    <p>Aquí irán los posts...</p>
@endsection
