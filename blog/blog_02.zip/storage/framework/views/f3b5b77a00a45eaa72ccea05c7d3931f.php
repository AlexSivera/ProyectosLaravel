<?php $__env->startSection('titulo', 'Ficha del post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha del post <?php echo e($id); ?></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/posts/ficha.blade.php ENDPATH**/ ?>