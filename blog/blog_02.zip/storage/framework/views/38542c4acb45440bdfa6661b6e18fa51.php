<?php $__env->startSection('titulo', 'Listado de posts'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Listado de posts</h1>
    <p>Aquí irán los posts...</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/posts/listado.blade.php ENDPATH**/ ?>