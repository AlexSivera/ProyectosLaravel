<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Página de inicio</h1>
    <p>Bienvenidos al blog</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/inicio.blade.php ENDPATH**/ ?>