<?php $__env->startSection('titulo', 'Ficha del post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1><?php echo e($post->titulo); ?></h1>

    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Contenido:</h5>
            <p class="card-text"><?php echo e($post->contenido); ?></p>
        </div>
        <div class="card-footer text-muted">
            Creado: <?php echo e($post->created_at->format('d/m/Y H:i')); ?>

            <?php if($post->created_at != $post->updated_at): ?>
                <br>Última modificación: <?php echo e($post->updated_at->format('d/m/Y H:i')); ?>

            <?php endif; ?>
        </div>
    </div>

    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary mt-3">
        Volver al listado
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>