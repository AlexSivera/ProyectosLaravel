<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <?php echo $__env->make('partials.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('contenido'); ?>
        </main>

        <footer class="mt-4 text-right">
            <small>Fecha actual: <?php echo e(fechaActual('d/m/Y')); ?></small>
        </footer>
    </div>

    <!-- Bootstrap JS (opcional) -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/plantilla.blade.php ENDPATH**/ ?>