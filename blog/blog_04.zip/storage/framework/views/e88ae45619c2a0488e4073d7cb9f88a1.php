<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(route('inicio')); ?>">Mi Blog</a>
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('inicio')); ?>">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">Listado de posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('posts.create')); ?>">Crear nuevo</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('posts.nuevoPrueba')); ?>">Crear post prueba</a>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /var/www/ProyectosLaravel/blog/resources/views/partials/nav.blade.php ENDPATH**/ ?>