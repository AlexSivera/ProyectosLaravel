<?php

function fechaActual($formato = 'd/m/Y')
{
    return date($formato);
}
