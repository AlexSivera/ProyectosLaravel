<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(route('inicio')); ?>">Mi Blog</a>
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('inicio')); ?>">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">Listado de posts</a>
            </li>
            <?php if(auth()->check()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('posts.create')); ?>">Crear nuevo</a>
                </li>
            <?php endif; ?>
        </ul>
        <ul class="navbar-nav ml-auto">
            <?php if(auth()->check()): ?>
                <li class="nav-item">
                    <span class="navbar-text mr-3"><?php echo e(auth()->user()->login); ?></span>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('logout')); ?>">Cerrar sesión</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH /var/www/html/ProyectosLaravel/blog/resources/views/partials/nav.blade.php ENDPATH**/ ?>