<?php $__env->startSection('titulo', 'Ficha del post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1><?php echo e($post->titulo); ?></h1>

    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Contenido:</h5>
            <p class="card-text"><?php echo e($post->contenido); ?></p>
        </div>
        <div class="card-footer text-muted">
            Creado: <?php echo e($post->created_at->format('d/m/Y H:i')); ?>

            <?php if($post->created_at != $post->updated_at): ?>
                <br>Última modificación: <?php echo e($post->updated_at->format('d/m/Y H:i')); ?>

            <?php endif; ?>
        </div>
    </div>

    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary mt-3">
        Volver al listado
    </a>
    
    <?php if(auth()->check() && auth()->user()->id === $post->usuario_id): ?>
        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-warning mt-3">Editar</a>

        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger mt-3"
                    onclick="return confirm('¿Eliminar este post?')">Borrar</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/ProyectosLaravel/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>