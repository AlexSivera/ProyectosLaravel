<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Página de inicio</h1>
    <p>Bienvenidos al blog</p>

    <!-- Esto es para mostrar mensajes cuando rediriges -->
    <?php if(session()->has('mensaje')): ?>
        <div class="alert alert-info">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/ProyectosLaravel/blog/resources/views/inicio.blade.php ENDPATH**/ ?>