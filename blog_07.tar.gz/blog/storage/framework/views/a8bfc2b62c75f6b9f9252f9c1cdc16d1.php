<?php $__env->startSection('titulo', 'Editar post'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Editar post</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('posts.update', $post)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="titulo">Título</label>
            <input type="text" name="titulo" id="titulo" class="form-control"
                   value="<?php echo e(old('titulo', $post->titulo)); ?>">
            <?php if($errors->has('titulo')): ?>
                <div class="text-danger"><?php echo e($errors->first('titulo')); ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="contenido">Contenido</label>
            <textarea name="contenido" id="contenido" class="form-control" rows="6"><?php echo e(old('contenido', $post->contenido)); ?></textarea>
            <?php if($errors->has('contenido')): ?>
                <div class="text-danger"><?php echo e($errors->first('contenido')); ?></div>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="<?php echo e(route('posts.show', $post)); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/ProyectosLaravel/blog/resources/views/posts/edit.blade.php ENDPATH**/ ?>