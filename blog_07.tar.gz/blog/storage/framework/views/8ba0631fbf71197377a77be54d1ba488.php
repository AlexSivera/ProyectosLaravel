<?php $__env->startSection('titulo', 'Listado de posts'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Listado de posts</h1>

    <?php if(session()->has('mensaje')): ?>
        <div class="alert alert-info">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <ul class="list-group">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <?php echo e($post->titulo); ?> (<?php echo e(optional($post->usuario)->login); ?>)
                    <br>
                    <small class="text-muted">
                        Creado: <?php echo e($post->created_at->format('d/m/Y H:i')); ?>

                    </small>
                </div>
                <div>
                    <a href="<?php echo e(route('posts.show', $post)); ?>" class="btn btn-info btn-sm">
                        Ver
                    </a>
                    <?php if(auth()->check() && auth()->user()->id === $post->usuario_id): ?>
                        <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn btn-warning btn-sm">
                            Editar
                        </a>
                        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" style="display: inline;">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('¿Eliminar este post?')">
                                Borrar
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="list-group-item">No hay posts para mostrar.</li>
        <?php endif; ?>
    </ul>

    <div class="mt-3">
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/ProyectosLaravel/blog/resources/views/posts/index.blade.php ENDPATH**/ ?>